# docker compose
docker-compose up -d --build

docker-compose stop

docker-compose rm