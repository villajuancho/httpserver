# kong-docker
docker-compose up
